﻿
using MimeKit;
using MsgKit;
using System;
using System.IO;
using System.Linq;


namespace EmltoMsg
{
    public class Class1
    {

        /// <summary>
        /// Converts a single EML file to MSG format.
        /// </summary>
        /// <param name="emlPath">Full path of the EML file.</param>
        /// <param name="msgPath">Destination path for the MSG file.</param>
        public void ConvertEmlToMsg(string emlPath, string msgPath)
        {


            // Load EML using MimeKit
            var mimeMessage = MimeMessage.Load(emlPath);

            // Extract sender info
            var fromAddress = mimeMessage.From.Mailboxes.FirstOrDefault();
            var sender = new Sender(fromAddress.Name ?? fromAddress.Address, fromAddress.Address);

            // Create MSG using MsgKit
            using (var email = new Email(sender, mimeMessage.Subject, mimeMessage.HtmlBody != null))
            {
                // Set body
                if (!string.IsNullOrEmpty(mimeMessage.HtmlBody))
                    email.BodyHtml = mimeMessage.HtmlBody;
                else
                    email.BodyText = mimeMessage.TextBody;

                // Add recipients
                foreach (var to in mimeMessage.To.Mailboxes)
                {
                    email.Recipients.AddTo(to.Name ?? to.Address, to.Address);
                }

                // Save MSG
                email.Save(msgPath);
            }

            Console.WriteLine("Conversion completed: " + msgPath);

        }




    }
}
